#pragma once

#include <string>

#include "../Singleton.hpp"
#include "../helpers/Utils.hpp"
#include "../math/QAngle.hpp"

class CUserCmd;
class QAngle;
class CViewSetup;

class Miscellaneous : public Singleton<Miscellaneous>
{
public:

	void Bhop(CUserCmd *userCMD);
	void AutoStrafe(CUserCmd *userCMD);
	static std::string GetLocalName();
	void ForceCrosshair();
	void Fakelag(CUserCmd *userCMD);
	void ChangeRegion();
	inline int32_t GetChocked() { return choked; }
	void ChangeName(const char* name);
	void FakeVote(const char* name);
	void FakeVac(const char* name);
	void FakeUnbox(const char* name);
	void FixName();
	void NameChanger();
	void ChatSpamer();
	void ClanTag();
	void ThirdPerson();
	void otuzbir();
	void FixMovement(CUserCmd *usercmd, QAngle &wish_angle);
	void AntiAim(CUserCmd *usercmd);
	void AutoPistol(CUserCmd *usercmd);
	void AldaVerdammteScheisse(CUserCmd *usercmd);

	void PunchAngleFix_RunCommand(void* base_player);
	void PunchAngleFix_FSN();

	int changes = -1;

	template<class T, class U>
	T clamp(T in, U low, U high);

private:

	const char *setStrRight(std::string txt, unsigned int value);
	std::string gladTag = " fantailcommunity.xyz ";
	QAngle m_aimPunchAngle[128];

	int32_t choked = 0;
};