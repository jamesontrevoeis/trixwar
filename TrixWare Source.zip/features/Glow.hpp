#pragma once

namespace Glow
{
	void RenderGlow();
	void ClearGlow();
}