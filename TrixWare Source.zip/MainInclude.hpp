#pragma once

#include "Structs.hpp"
#include "Install.hpp"
#include "interfaces/IClientEntity.hpp"
#include "helpers/math.hpp"
#include "helpers/utils.hpp"
#include "interfaces/ILocalize.hpp"
#include "options.hpp"
#include "singleton.hpp"
#include "interfaces/CInput.hpp"
#include "interfaces/IGameEventmanager.hpp"
#include "interfaces\IMDLCache.hpp"